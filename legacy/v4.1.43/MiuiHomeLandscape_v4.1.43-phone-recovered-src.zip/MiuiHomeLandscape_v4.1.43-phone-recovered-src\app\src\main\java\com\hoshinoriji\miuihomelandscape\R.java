package com.hoshinoriji.miuihomelandscape;

public final class R {

    public static final class array {
        public static int xposed_scope = 0x7f010000;

        private array() {
        }
    }

    public static final class string {
        public static int app_desc = 0x7f020000;
        public static int app_name = 0x7f020001;
        public static int author = 0x7f020002;
        public static int disclaimer = 0x7f020003;

        private string() {
        }
    }

    private R() {
    }
}
