package com.hoshinoriji.miuihomelandscape;

public final class LandscapeBridge {
    public static final String ACTION_ADD_RESULT = "com.hoshinoriji.miuihomelandscape.ADD_RESULT";
    public static final String ACTION_ADD_TO_LANDSCAPE = "com.hoshinoriji.miuihomelandscape.ADD_TO_LANDSCAPE";
    public static final String ACTION_IMPORT_ALL = "com.hoshinoriji.miuihomelandscape.IMPORT_ALL";
    public static final String ACTION_PING = "com.hoshinoriji.miuihomelandscape.PING_HOME";
    public static final String ACTION_PONG = "com.hoshinoriji.miuihomelandscape.PONG_HOME";
    public static final String ACTION_SETTINGS_UPDATE = "com.hoshinoriji.miuihomelandscape.SETTINGS_UPDATE";
    public static final String EXTRA_ADDED = "added";
    public static final String EXTRA_CLASS = "class_name";
    public static final String EXTRA_HIDE_GESTURE_HANDLE = "hide_gesture_handle";
    public static final String EXTRA_MESSAGE = "message";
    public static final String EXTRA_PACKAGE = "package_name";
    public static final String EXTRA_USER_SERIAL = "user_serial";
    public static final String EXTRA_VERSION = "version";
    public static final String HOME_PKG = "com.miui.home";
    public static final String MODULE_PKG = "com.hoshinoriji.miuihomelandscape";

    private LandscapeBridge() {
    }
}
